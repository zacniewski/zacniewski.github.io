---
title: "Aplikacje mobilne dla systemu Android"
collection: teaching
type: "Wykłady i laboratoria"
permalink: /teaching/2019-android
venue: "AMW, WNiUO"
date: 2019-02-01
location: "Gdynia, Polska"
---

Zagadnienia i sposób zaliczenia:

Coming soon ...
